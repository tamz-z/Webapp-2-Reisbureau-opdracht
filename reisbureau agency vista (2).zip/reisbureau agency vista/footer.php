<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/sheetstylefooter.css">
</head>

<footer>
    <div class="footerlijn01"></div>
    <div id="footerflex">
        <div class="footer1stehelft">
            <img src="" class="">
            <div class="footerlijn02"></div>
            <h2>Contact Details</h2>
            <h1>06382784772</h1>
            <h1>AgencyVista@outlook.com</h1>
            <h1>Domiscusstraat 12 Amsterdam</h1>
            <div class="footerlijn02"></div>
            <h2>Our socials</h2>
            <div style="position: relative; left: 10px; top :10px;">
                <img class="socialsicon" src="img/instagram.png" alt="">
                <img class="socialsicon" src="img/facebook.png" alt="">
                <img class="socialsicon" src="img/twitter.png" alt="">
            </div>
        </div>
        <div class="footer2stehelft">
            <h1 style="font-size: 30px;">Stay Up-to-Date with Our Newsletter</h1>
            <div id="emailgrid">
                <h2>Enter your email here ></h2>
                <input class="emailbalk" type="email" name="email" placeholder="Your Email" required>
            </div>
            <div class="footerlijn02"></div>
            <h2> Thanks you for Subscribing!</h2>
        </div>
    </div>
</footer>